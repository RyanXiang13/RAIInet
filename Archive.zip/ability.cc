#include <memory>
#include "link.h"
#include "cell.h"
#include "player.h"
#include "ability.h"

// no implementation needed for pure virtual use
// no implementation needed for destructor
